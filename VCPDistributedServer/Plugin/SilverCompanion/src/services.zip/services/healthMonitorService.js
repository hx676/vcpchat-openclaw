const { METRIC_CONFIG } = require('../types/constants');

function latestItem(list = []) {
    return Array.isArray(list) && list.length ? list[list.length - 1] : null;
}

class HealthMonitorService {
    constructor({ store }) {
        this.store = store;
    }

    async getHealthData() {
        return this.store.readFile('health');
    }

    async getMetricTimeline(metric, range = '24h') {
        const health = await this.getHealthData();
        const series = health.metrics[metric];
        if (!Array.isArray(series)) {
            throw new Error(`Unsupported metric: ${metric}`);
        }

        const normalizedRange = range === '7d' ? '7d' : '24h';
        const hourlyMetrics = new Set(['heartRate', 'bloodOxygen']);

        if (normalizedRange === '24h' && series.length > 24) {
            return series.slice(-24);
        }
        if (normalizedRange === '7d') {
            if (hourlyMetrics.has(metric) && series.length > 24 * 7) {
                return series.slice(-(24 * 7));
            }
            if (!hourlyMetrics.has(metric) && series.length > 7) {
                return series.slice(-7);
            }
        }
        return series;
    }

    computeAlerts(health) {
        const heartRateLatest = latestItem(health.metrics.heartRate);
        const bloodOxygenLatest = latestItem(health.metrics.bloodOxygen);
        const sleepLatest = latestItem(health.metrics.sleep);
        const battery = health.device?.battery ?? 100;
        const lastSync = health.device?.lastSyncAt ? Date.parse(health.device.lastSyncAt) : Date.now();
        const minutesSinceSync = Math.round((Date.now() - lastSync) / 60000);

        const alerts = [];

        if (heartRateLatest && heartRateLatest.value >= 100) {
            alerts.push({ key: 'heart_rate', severity: 'high', title: '心率升高', message: `最新心率 ${heartRateLatest.value} bpm，建议先安静休息并关注是否持续。` });
        }
        if (bloodOxygenLatest && bloodOxygenLatest.value <= 94) {
            alerts.push({ key: 'blood_oxygen', severity: 'high', title: '血氧偏低', message: `最新血氧 ${bloodOxygenLatest.value}% ，建议尽快复测并关注呼吸状态。` });
        }
        if (sleepLatest && sleepLatest.durationHours < 6) {
            alerts.push({ key: 'sleep', severity: 'medium', title: '睡眠下降', message: `昨夜睡眠 ${sleepLatest.durationHours} 小时，夜醒 ${sleepLatest.wakeCount} 次，今日陪伴应更温和。` });
        }
        if (battery <= 20) {
            alerts.push({ key: 'battery', severity: 'medium', title: '设备低电', message: `当前电量 ${battery}% ，建议尽快补电，避免守护中断。` });
        }
        if (!health.device?.connected || minutesSinceSync > 45) {
            alerts.push({ key: 'sync', severity: 'medium', title: '同步异常', message: `设备最近 ${minutesSinceSync} 分钟未同步，需要留意连接状态。` });
        }

        return alerts;
    }

    buildCards(health) {
        const heartRateLatest = latestItem(health.metrics.heartRate);
        const bloodOxygenLatest = latestItem(health.metrics.bloodOxygen);
        const sleepLatest = latestItem(health.metrics.sleep);
        const bloodPressureLatest = latestItem(health.metrics.bloodPressure);
        const activityLatest = latestItem(health.metrics.activity);

        return [
            {
                key: 'heartRate',
                label: METRIC_CONFIG.heartRate.label,
                displayValue: heartRateLatest ? `${heartRateLatest.value} ${METRIC_CONFIG.heartRate.unit}` : '--',
                status: heartRateLatest && heartRateLatest.value >= 100 ? 'danger' : 'ok',
                deltaLabel: heartRateLatest && heartRateLatest.value >= 90 ? '较平时偏高' : '整体平稳',
            },
            {
                key: 'bloodOxygen',
                label: METRIC_CONFIG.bloodOxygen.label,
                displayValue: bloodOxygenLatest ? `${bloodOxygenLatest.value}${METRIC_CONFIG.bloodOxygen.unit}` : '--',
                status: bloodOxygenLatest && bloodOxygenLatest.value <= 94 ? 'danger' : 'ok',
                deltaLabel: bloodOxygenLatest && bloodOxygenLatest.value <= 95 ? '建议复测' : '处于舒适区间',
            },
            {
                key: 'sleep',
                label: METRIC_CONFIG.sleep.label,
                displayValue: sleepLatest ? `${sleepLatest.durationHours}${METRIC_CONFIG.sleep.unit}` : '--',
                status: sleepLatest && sleepLatest.durationHours < 6 ? 'watch' : 'ok',
                deltaLabel: sleepLatest ? `夜醒 ${sleepLatest.wakeCount} 次` : '暂无数据',
            },
            {
                key: 'bloodPressure',
                label: METRIC_CONFIG.bloodPressure.label,
                displayValue: bloodPressureLatest ? `${bloodPressureLatest.systolic}/${bloodPressureLatest.diastolic}` : '--',
                status: bloodPressureLatest && bloodPressureLatest.systolic >= 140 ? 'watch' : 'ok',
                deltaLabel: bloodPressureLatest && bloodPressureLatest.systolic >= 135 ? '收缩压偏高' : '波动可接受',
            },
            {
                key: 'activity',
                label: METRIC_CONFIG.activity.label,
                displayValue: activityLatest ? `${activityLatest.steps}${METRIC_CONFIG.activity.unit}` : '--',
                status: activityLatest && activityLatest.steps < 3000 ? 'watch' : 'ok',
                deltaLabel: activityLatest ? `${activityLatest.activeMinutes} 分钟活动` : '暂无数据',
            },
        ];
    }

    determineRiskLevel(alerts) {
        if (alerts.some((item) => item.severity === 'high')) return 'high';
        if (alerts.length > 0) return 'medium';
        return 'low';
    }

    async getHealthOverview() {
        const health = await this.getHealthData();
        const alerts = this.computeAlerts(health);

        return {
            updatedAt: health.updatedAt,
            device: health.device,
            cards: this.buildCards(health),
            alerts,
            riskLevel: this.determineRiskLevel(alerts),
        };
    }
}

module.exports = HealthMonitorService;
