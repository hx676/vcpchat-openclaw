const crypto = require('crypto');

function buildMessage(role, channel, text) {
    return {
        id: `msg_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`,
        role,
        channel,
        text,
        createdAt: new Date().toISOString(),
    };
}

class MemoryProfileService {
    constructor({ store }) {
        this.store = store;
    }

    async getMemoryProfile() {
        return this.store.readFile('memory');
    }

    async getConversation() {
        return this.store.readFile('conversation');
    }

    async recordExchange({ userText, assistantText, channel }) {
        const userMessage = buildMessage('user', channel || 'text', userText);
        const assistantMessage = buildMessage('assistant', 'text', assistantText);

        await this.store.updateFile('conversation', (conversation) => {
            const nextMessages = [...conversation.messages, userMessage, assistantMessage].slice(-30);
            return {
                ...conversation,
                updatedAt: new Date().toISOString(),
                messages: nextMessages,
                proactive: {
                    ...conversation.proactive,
                    lastGreetingAt: new Date().toISOString(),
                },
            };
        });

        await this.store.updateFile('memory', (memory) => ({
            ...memory,
            updatedAt: new Date().toISOString(),
            shortTerm: {
                ...memory.shortTerm,
                lastTopic: userText,
                lastMoodTag: /累|困|没精神|不舒服|难受/.test(userText) ? '需要多留意' : '平稳',
            },
            midTerm: {
                ...memory.midTerm,
                recentPatterns: [
                    `最近一次主动表达：${userText}`,
                    ...memory.midTerm.recentPatterns,
                ].slice(0, 4),
            },
        }));

        return { userMessage, assistantMessage };
    }
}

module.exports = MemoryProfileService;
