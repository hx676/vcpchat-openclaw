const crypto = require('crypto');
const path = require('path');

const { resolveVcpApiKey } = require(path.join(__dirname, '..', '..', '..', '..', '..', 'modules', 'utils', 'vcpKeyResolver'));
const { createCompanionReply } = require('../adapters/companionReplyAdapter');
const { EMPTY_ANALYZER_RESULT } = require('../types/agentContracts');
const LongTermMemoryService = require('./longTermMemoryService');

function stripCodexModelPrefix(model) {
    const value = String(model || '').trim();
    if (!value.toLowerCase().startsWith('openai-codex/')) return value;
    return value.slice('openai-codex/'.length).trim();
}

function shouldRetryWithStrippedCodexModel(status, rawBody, model) {
    if (status !== 400) return false;
    const current = String(model || '').trim();
    if (!current.toLowerCase().startsWith('openai-codex/')) return false;
    return String(rawBody || '').toLowerCase().includes('not supported when using codex with a chatgpt account');
}

function cloneAnalyzerResult(result) {
    return {
        ...EMPTY_ANALYZER_RESULT,
        ...result,
        family_key_events: Array.isArray(result && result.family_key_events) ? result.family_key_events : [],
        family_actions: Array.isArray(result && result.family_actions) ? result.family_actions : [],
        memory_tags: Array.isArray(result && result.memory_tags) ? result.memory_tags : [],
    };
}

class AgentOrchestratorService {
    constructor({
        projectRoot,
        settingsManager,
        store,
        agentConfigService,
        healthService,
        emotionService,
        safeCircleService,
        memoryService,
        familySummaryService,
    }) {
        this.projectRoot = projectRoot;
        this.settingsManager = settingsManager;
        this.store = store;
        this.agentConfigService = agentConfigService;
        this.healthService = healthService;
        this.emotionService = emotionService;
        this.safeCircleService = safeCircleService;
        this.memoryService = memoryService;
        this.familySummaryService = familySummaryService;
        this.longTermMemoryService = new LongTermMemoryService({ projectRoot, store });
    }

    async ensureReady() {
        await this.agentConfigService.ensureAgents();
    }

    async buildContextPacket(payload = {}) {
        const results = await Promise.all([
            this.store.readFile('profile'),
            this.healthService.getHealthOverview(),
            this.safeCircleService.getSafeCircleOverview(),
            this.memoryService.getConversation(),
            this.memoryService.getMemoryProfile(),
        ]);

        const profile = results[0];
        const healthOverview = results[1];
        const safeCircleOverview = results[2];
        const conversation = results[3];
        const memory = results[4];
        const emotionOverview = await this.emotionService.getEmotionOverview(healthOverview, safeCircleOverview);

        return {
            profile: {
                name: profile.name,
                age: profile.age,
                city: profile.city,
                relationshipRole: profile.relationshipRole,
                motto: profile.motto,
                preferences: profile.preferences || [],
                family: profile.family || [],
                tags: profile.tags || [],
            },
            health: {
                riskLevel: healthOverview.riskLevel,
                cards: healthOverview.cards,
                alerts: healthOverview.alerts,
                device: healthOverview.device,
            },
            emotionSignals: {
                riskLevel: emotionOverview.riskLevel,
                signals: emotionOverview.signals,
                narrative: emotionOverview.narrative.slice(0, 4),
            },
            safeCircle: {
                warningCount: safeCircleOverview.warningCount,
                warnings: safeCircleOverview.warnings,
                checkInLabel: safeCircleOverview.checkInLabel,
                contacts: safeCircleOverview.contacts,
            },
            recentConversation: {
                messages: (conversation.messages || []).slice(-8).map((message) => ({
                    role: message.role,
                    channel: message.channel,
                    text: message.text,
                    createdAt: message.createdAt,
                })),
                proactive: conversation.proactive || {},
            },
            memory: {
                shortTerm: memory.shortTerm || {},
                midTerm: memory.midTerm || {},
                longTerm: memory.longTerm || {},
                longTermLastWriteAt: memory.longTermLastWriteAt || null,
                longTermLastWriteSummary: memory.longTermLastWriteSummary || '',
                longTermNotebook: memory.longTermNotebook || '银发陪伴助手',
            },
            userInput: {
                text: String(payload.text || '').trim(),
                channel: payload.channel || 'text',
            },
            scene: payload.scene || 'silver_companion',
        };
    }

    buildSystemPrompt(agentRuntime) {
        const config = agentRuntime.config || {};
        const topicCreatedAt = new Date(agentRuntime.topicCreatedAt || Date.now()).toISOString();
        const prepended = [
            `当前聊天记录文件路径: ${agentRuntime.historyFile}`,
            `当前话题创建于: ${topicCreatedAt}`,
        ];
        const basePrompt = String(config.systemPrompt || '').replace(/\{\{AgentName\}\}/g, config.name || agentRuntime.name);
        return `${prepended.join('\n')}\n\n${basePrompt}`.trim();
    }

    buildModelConfig(agentRuntime) {
        const config = agentRuntime.config || {};
        return {
            model: config.model || 'gpt-5.4-mini',
            temperature: config.temperature !== undefined ? Number(config.temperature) : 0.7,
            max_tokens: config.maxOutputTokens ? Number(config.maxOutputTokens) : 12000,
            contextTokenLimit: config.contextTokenLimit ? Number(config.contextTokenLimit) : 128000,
            stream: false,
        };
    }

    async sendMessagesToVcp(messages, modelConfig) {
        const settings = await this.settingsManager.readSettings();
        if (!settings || !settings.vcpServerUrl) {
            throw new Error('未配置 vcpServerUrl，无法调用 SilverCompanion Agent。');
        }

        let finalUrl = settings.vcpServerUrl;
        if (settings.enableVcpToolInjection === true) {
            const urlObject = new URL(finalUrl);
            urlObject.pathname = '/v1/chatvcp/completions';
            finalUrl = urlObject.toString();
        }

        const key = resolveVcpApiKey({
            projectRoot: this.projectRoot,
            vcpUrl: finalUrl,
            configuredKey: settings.vcpApiKey || '',
        }).effectiveKey;

        if (!key) {
            throw new Error('未配置 vcpApiKey，无法调用 SilverCompanion Agent。');
        }

        const requestBody = {
            messages,
            ...modelConfig,
            stream: false,
            requestId: `silver_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`,
        };

        let response = await fetch(finalUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${key}`,
            },
            body: JSON.stringify(requestBody),
        });

        if (!response.ok) {
            let errorText = await response.text();

            if (shouldRetryWithStrippedCodexModel(response.status, errorText, requestBody.model)) {
                const fallbackModel = stripCodexModelPrefix(requestBody.model);
                if (fallbackModel && fallbackModel !== requestBody.model) {
                    requestBody.model = fallbackModel;
                    response = await fetch(finalUrl, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            Authorization: `Bearer ${key}`,
                        },
                        body: JSON.stringify(requestBody),
                    });
                    if (!response.ok) {
                        errorText = await response.text();
                    }
                }
            }

            if (!response.ok) {
                throw new Error(`SilverCompanion Agent 调用失败: ${response.status} - ${errorText}`);
            }
        }

        const data = await response.json();
        return String(data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content || '').trim();
    }

    buildAnalyzerMessages(agentRuntime, contextPacket) {
        return [
            { role: 'system', content: this.buildSystemPrompt(agentRuntime) },
            {
                role: 'user',
                content: [
                    '请基于以下 SilverCompanionContextPacket 做情绪分析和家属摘要，严格返回 JSON。',
                    JSON.stringify(contextPacket, null, 2),
                ].join('\n\n'),
            },
        ];
    }

    buildCompanionMessages(agentRuntime, contextPacket, analyzerResult) {
        return [
            { role: 'system', content: this.buildSystemPrompt(agentRuntime) },
            {
                role: 'user',
                content: [
                    '请基于以下上下文生成适合老人端的陪伴回复。',
                    JSON.stringify({
                        context: contextPacket,
                        analyzer: analyzerResult,
                    }, null, 2),
                ].join('\n\n'),
            },
        ];
    }

    extractJsonObject(rawText) {
        const text = String(rawText || '').trim();
        if (!text) {
            throw new Error('分析 Agent 返回为空。');
        }

        const fencedMatch = text.match(/```json\s*([\s\S]*?)```/i);
        const candidate = fencedMatch ? fencedMatch[1].trim() : text;

        try {
            return JSON.parse(candidate);
        } catch (_error) {
            const start = candidate.indexOf('{');
            const end = candidate.lastIndexOf('}');
            if (start !== -1 && end !== -1 && end > start) {
                return JSON.parse(candidate.slice(start, end + 1));
            }
            throw new Error('分析 Agent 未返回合法 JSON。');
        }
    }

    normalizeAnalyzerResult(rawResult) {
        const result = cloneAnalyzerResult(rawResult);
        if (!['low', 'medium', 'high'].includes(result.emotion_risk_level)) {
            result.emotion_risk_level = 'medium';
        }
        if (!['low', 'medium', 'high'].includes(result.memory_priority)) {
            result.memory_priority = 'medium';
        }
        result.memory_should_write = result.memory_should_write === true;
        return result;
    }

    async persistAnalyzerResult(range, analyzerResult) {
        const nowIso = new Date().toISOString();
        const source = analyzerResult.source || 'agent';

        await this.store.updateFile('emotion', (emotion) => ({
            ...emotion,
            updatedAt: nowIso,
            agentAnalysis: {
                emotion_summary: analyzerResult.emotion_summary,
                emotion_risk_level: analyzerResult.emotion_risk_level,
                companion_guidance: analyzerResult.companion_guidance,
                confidence_note: analyzerResult.confidence_note,
                memory_should_write: analyzerResult.memory_should_write,
                memory_summary: analyzerResult.memory_summary,
                memory_tags: analyzerResult.memory_tags,
                memory_priority: analyzerResult.memory_priority,
                updatedAt: nowIso,
                source,
            },
        }));

        await this.store.updateFile('summary', (summary) => ({
            ...summary,
            updatedAt: nowIso,
            agentOutputs: {
                ...(summary.agentOutputs || {}),
                [range]: {
                    headline: analyzerResult.family_summary_headline,
                    keyEvents: analyzerResult.family_key_events,
                    recommendedActions: analyzerResult.family_actions,
                    emotion_summary: analyzerResult.emotion_summary,
                    emotion_risk_level: analyzerResult.emotion_risk_level,
                    companion_guidance: analyzerResult.companion_guidance,
                    confidence_note: analyzerResult.confidence_note,
                    memory_should_write: analyzerResult.memory_should_write,
                    memory_summary: analyzerResult.memory_summary,
                    memory_tags: analyzerResult.memory_tags,
                    memory_priority: analyzerResult.memory_priority,
                    updatedAt: nowIso,
                    source,
                },
            },
        }));
    }

    buildFallbackAnalyzerResult(contextPacket, familySummary, emotionOverview) {
        return {
            emotion_summary: emotionOverview.narrative[0] || '当前情绪趋势整体平稳，但建议继续保持温和陪伴。',
            emotion_risk_level: emotionOverview.riskLevel,
            family_summary_headline: familySummary.headline,
            family_key_events: familySummary.keyEvents,
            family_actions: familySummary.recommendedActions,
            companion_guidance: '请继续保持自然、温和、低压迫感的陪伴方式，避免连续追问。',
            confidence_note: '本次为本地规则降级结果。',
            memory_should_write: false,
            memory_summary: '',
            memory_tags: [],
            memory_priority: 'low',
            source: 'fallback',
        };
    }

    async maybeWriteLongTermMemory(contextPacket, analyzerResult) {
        if (!analyzerResult.memory_should_write) {
            return { success: false, skipped: true, reason: 'memory_should_write_false' };
        }

        if (!String(analyzerResult.memory_summary || '').trim()) {
            return { success: false, skipped: true, reason: 'empty_memory_summary' };
        }

        return this.longTermMemoryService.writeCompanionMemory({
            summary: analyzerResult.memory_summary,
            tags: analyzerResult.memory_tags,
            priority: analyzerResult.memory_priority,
            source: contextPacket.scene || 'silver_companion',
        });
    }

    async runAnalyzer(contextPacket, range) {
        const analyzerRuntime = await this.agentConfigService.getAgentRuntime('analyzer');
        const fallbackHealthOverview = await this.healthService.getHealthOverview();
        const fallbackSafeCircleOverview = await this.safeCircleService.getSafeCircleOverview();
        const fallbackEmotionOverview = await this.emotionService.getEmotionOverview(fallbackHealthOverview, fallbackSafeCircleOverview);
        const fallbackFamilySummary = await this.familySummaryService.getSummary(range, {
            healthOverview: fallbackHealthOverview,
            emotionOverview: fallbackEmotionOverview,
            safeCircleOverview: fallbackSafeCircleOverview,
        }, { preferAgent: false });

        try {
            const rawText = await this.sendMessagesToVcp(
                this.buildAnalyzerMessages(analyzerRuntime, contextPacket),
                this.buildModelConfig(analyzerRuntime)
            );

            const parsed = this.normalizeAnalyzerResult(this.extractJsonObject(rawText));
            await this.persistAnalyzerResult(range, parsed);
            await this.agentConfigService.appendAgentHistory('analyzer', [
                { role: 'user', content: JSON.stringify(contextPacket), timestamp: Date.now() },
                { role: 'assistant', content: JSON.stringify(parsed), timestamp: Date.now() },
            ]);
            return parsed;
        } catch (_error) {
            const fallback = this.buildFallbackAnalyzerResult(contextPacket, fallbackFamilySummary, fallbackEmotionOverview);
            await this.persistAnalyzerResult(range, fallback);
            return fallback;
        }
    }

    async runCompanion(contextPacket, analyzerResult) {
        const companionRuntime = await this.agentConfigService.getAgentRuntime('companion');
        try {
            const responseText = await this.sendMessagesToVcp(
                this.buildCompanionMessages(companionRuntime, contextPacket, analyzerResult),
                this.buildModelConfig(companionRuntime)
            );

            if (responseText) {
                await this.agentConfigService.appendAgentHistory('companion', [
                    {
                        role: 'user',
                        content: JSON.stringify({
                            userInput: contextPacket.userInput,
                            analyzer: analyzerResult,
                        }),
                        timestamp: Date.now(),
                    },
                    {
                        role: 'assistant',
                        content: responseText,
                        timestamp: Date.now(),
                    },
                ]);
                return responseText;
            }
        } catch (_error) {
            // Fall through to local fallback.
        }

        return createCompanionReply({
            userText: contextPacket.userInput.text,
            profile: contextPacket.profile,
            healthState: contextPacket.health,
            emotionState: {
                riskLevel: analyzerResult.emotion_risk_level,
                signals: [],
            },
            safeCircleState: {
                warningCount: contextPacket.safeCircle.warningCount,
            },
            familySummary: {
                headline: analyzerResult.family_summary_headline,
            },
            proactive: !contextPacket.userInput.text,
        });
    }

    async analyzeAndRespond(payload = {}) {
        await this.ensureReady();
        const range = payload.summaryRange || 'daily';
        const contextPacket = await this.buildContextPacket(payload);
        const analyzerResult = await this.runAnalyzer(contextPacket, range);
        const memoryWriteResult = await this.maybeWriteLongTermMemory(contextPacket, analyzerResult);
        const companionText = await this.runCompanion(contextPacket, analyzerResult);

        return {
            contextPacket,
            analyzerResult,
            memoryWriteResult,
            companionText,
        };
    }
}

module.exports = AgentOrchestratorService;
